# Washing Machine — Parallel and Coupled FSM Workshop

Interactive, two-exercise Streamlit app. Diagram elements are clickable via embedded HTML/SVG, with selections synchronized to Streamlit through a small custom component (no external packages needed beyond Streamlit).

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
Upload `app.py` and `requirements.txt` to a GitHub repository, then deploy `app.py` on Streamlit Community Cloud.
